#pragma warning disable 1591

namespace Open.SmsSender
{
    using System;
    using System.Security.Cryptography.X509Certificates;
    using System.Net;
    using System.Net.Security;

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Web.Services", "2.0.50727.3053")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Web.Services.WebServiceBindingAttribute(Name = "SmswebsrvControllerBinding", Namespace = "urn:SmswebsrvControllerwsdl")]
    public partial class WebClient : System.Web.Services.Protocols.SoapHttpClientProtocol
    {

        private System.Threading.SendOrPostCallback sendSmsOperationCompleted;

        private System.Threading.SendOrPostCallback getStatusOperationCompleted;

        private bool useDefaultCredentialsSetExplicitly;

        /// <remarks/>
        public WebClient(string url, string userName, string password)
        {
            ServicePointManager.ServerCertificateValidationCallback += delegate (object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors)
            {
                return true;
            };

            this.Url = url;

            System.Net.CredentialCache myCredentials = new System.Net.CredentialCache();
            NetworkCredential netCred = new NetworkCredential(userName, password);
            myCredentials.Add(new Uri(url), "Basic", netCred);
            this.Credentials = myCredentials;

            if ((this.IsLocalFileSystemWebService(this.Url) == true))
            {
                this.UseDefaultCredentials = true;
                this.useDefaultCredentialsSetExplicitly = false;
            }
            else
            {
                this.useDefaultCredentialsSetExplicitly = true;
            }
        }

        public new string Url
        {
            get
            {
                return base.Url;
            }
            set
            {
                if ((((this.IsLocalFileSystemWebService(base.Url) == true)
                            && (this.useDefaultCredentialsSetExplicitly == false))
                            && (this.IsLocalFileSystemWebService(value) == false)))
                {
                    base.UseDefaultCredentials = false;
                }
                base.Url = value;
            }
        }

        public new bool UseDefaultCredentials
        {
            get
            {
                return base.UseDefaultCredentials;
            }
            set
            {
                base.UseDefaultCredentials = value;
                this.useDefaultCredentialsSetExplicitly = true;
            }
        }

        /// <remarks/>
        public event sendSmsCompletedEventHandler sendSmsCompleted;

        /// <remarks/>
        public event getStatusCompletedEventHandler getStatusCompleted;

        /// <remarks/>

        [System.Web.Services.Protocols.SoapRpcMethodAttribute("urn:SmswebsrvControllerwsdl#sendSms", RequestNamespace = "urn:SmswebsrvControllerwsdl", ResponseNamespace = "urn:SmswebsrvControllerwsdl")]
        [return: System.Xml.Serialization.SoapElementAttribute("return")]
        public string[] sendSms(string phone, string text, string title, string client_code, int aggregator_id)
        {
            object[] results = null;
            object[] arrParam = new object[] { phone, text, title, client_code, aggregator_id };
            //string[] resultsString

            results = this.Invoke("sendSms", arrParam);

            return ((string[])(results[0]));
        }

        /// <remarks/>
        public void sendSmsAsync(string phone, string text, string title, string client_code, int aggregator_id)
        {
            this.sendSmsAsync(phone, text, title, client_code, aggregator_id, null);
        }

        /// <remarks/>
        public void sendSmsAsync(string phone, string text, string title, string client_code, int aggregator_id, object userState)
        {
            if ((this.sendSmsOperationCompleted == null))
            {
                this.sendSmsOperationCompleted = new System.Threading.SendOrPostCallback(this.OnsendSmsOperationCompleted);
            }

            object[] arrParam = new object[] { phone, text, title, client_code, aggregator_id };

            this.InvokeAsync("sendSms", arrParam, this.sendSmsOperationCompleted, userState);
        }

        private void OnsendSmsOperationCompleted(object arg)
        {
            if ((this.sendSmsCompleted != null))
            {
                System.Web.Services.Protocols.InvokeCompletedEventArgs invokeArgs = ((System.Web.Services.Protocols.InvokeCompletedEventArgs)(arg));
                this.sendSmsCompleted(this, new sendSmsCompletedEventArgs(invokeArgs.Results, invokeArgs.Error, invokeArgs.Cancelled, invokeArgs.UserState));
            }
        }

        /// <remarks/>
        [System.Web.Services.Protocols.SoapRpcMethodAttribute("urn:SmswebsrvControllerwsdl#getStatus", RequestNamespace = "urn:SmswebsrvControllerwsdl", ResponseNamespace = "urn:SmswebsrvControllerwsdl")]
        [return: System.Xml.Serialization.SoapElementAttribute("return")]
        public string[] getStatus(int sms_id)
        {
            object[] results = this.Invoke("getStatus", new object[] {sms_id});
            return ((string[])(results[0]));
        }

        /// <remarks/>
        public void getStatusAsync(int sms_id)
        {
            this.getStatusAsync(sms_id, null);
        }

        /// <remarks/>
        public void getStatusAsync(int sms_id, object userState)
        {
            if ((this.getStatusOperationCompleted == null))
            {
                this.getStatusOperationCompleted = new System.Threading.SendOrPostCallback(this.OngetStatusOperationCompleted);
            }
            this.InvokeAsync("getStatus", new object[] {
                        sms_id}, this.getStatusOperationCompleted, userState);
        }

        private void OngetStatusOperationCompleted(object arg)
        {
            if ((this.getStatusCompleted != null))
            {
                System.Web.Services.Protocols.InvokeCompletedEventArgs invokeArgs = ((System.Web.Services.Protocols.InvokeCompletedEventArgs)(arg));
                this.getStatusCompleted(this, new getStatusCompletedEventArgs(invokeArgs.Results, invokeArgs.Error, invokeArgs.Cancelled, invokeArgs.UserState));
            }
        }

        /// <remarks/>
        public new void CancelAsync(object userState)
        {
            base.CancelAsync(userState);
        }

        private bool IsLocalFileSystemWebService(string url)
        {
            if (((url == null)
                        || (url == string.Empty)))
            {
                return false;
            }
            System.Uri wsUri = new System.Uri(url);
            if (((wsUri.Port >= 1024)
                        && (string.Compare(wsUri.Host, "localHost", System.StringComparison.OrdinalIgnoreCase) == 0)))
            {
                return true;
            }
            return false;
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Web.Services", "2.0.50727.3053")]
    public delegate void sendSmsCompletedEventHandler(object sender, sendSmsCompletedEventArgs e);

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Web.Services", "2.0.50727.3053")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    public partial class sendSmsCompletedEventArgs : System.ComponentModel.AsyncCompletedEventArgs
    {

        private object[] results;

        internal sendSmsCompletedEventArgs(object[] results, System.Exception exception, bool cancelled, object userState)
            :
                base(exception, cancelled, userState)
        {
            this.results = results;
        }

        /// <remarks/>
        public string Result
        {
            get
            {
                this.RaiseExceptionIfNecessary();
                return ((string)(this.results[0]));
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Web.Services", "2.0.50727.3053")]
    public delegate void getStatusCompletedEventHandler(object sender, getStatusCompletedEventArgs e);

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Web.Services", "2.0.50727.3053")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    public partial class getStatusCompletedEventArgs : System.ComponentModel.AsyncCompletedEventArgs
    {

        private object[] results;

        internal getStatusCompletedEventArgs(object[] results, System.Exception exception, bool cancelled, object userState)
            :
                base(exception, cancelled, userState)
        {
            this.results = results;
        }

        /// <remarks/>
        public string Result
        {
            get
            {
                this.RaiseExceptionIfNecessary();
                return ((string)(this.results[0]));
            }
        }
    }
}

#pragma warning restore 1591