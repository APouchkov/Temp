using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.SqlServer.Server;
using System.Data.SqlTypes;
using System.Threading;


// Для развертывания на сервере нужно собрать еще одну сборку Open.SmsSender.XmlSerializers.dll
// Для этого нужно выполнить команду:
// 1. Пуск->Программы->Microsoft Visual Studio 2005->Visual Studio Tools->Visual Studio 2005 Command Prompt
// 2. sgen.exe /force "C:\dmitryyk\VSS\SERVER\Common\Assemblies\Open.SmsSender\Src\Open.SmsSender\bin\Debug\Open.SmsSender.dll"
namespace Open.SmsSender
{
    public static class Manager
    {
        /// <summary>
        /// Возвращаемый результат:
        /// 0 - не доставлено
        /// 1 - отправлено
        /// 2 - ошибка отправки (например, ошибка биллинга)
        /// 3 - ошибка доставки (например, истек срок доставки или номер более не обслуживается)
        /// 4 - неизвестная ошибка
        /// 5 - time out
        /// 
        /// см. http://jira.open.ru/browse/PR-859
        /// </summary>
        [SqlProcedure(Name = "sms_send")]
        public static SqlInt32 SmsSend(SqlString phone, SqlString text, SqlString title, ref SqlString statusMsg, SqlInt32 timeOut, SqlString url, SqlString userName, SqlString password, SqlInt32 aggregator_id, SqlString clientCode)
        {
            if (timeOut <= 0)
                throw new Exception("Параметр timeOut должен быть больше 0.");

            WebClient srv = new WebClient(url.Value, userName.Value, password.Value);

            // Посылаем SMS
            string[] resSend = srv.sendSms(phone.Value, text.Value, title.Value, clientCode.Value, aggregator_id.Value);
            int resProc = int.Parse(resSend[0]);
            statusMsg = resSend[1];
            
            // Процесс отправки SMS запущен успешно
            if (resProc == 1)
            {
                DateTime dtStop = DateTime.Now.AddSeconds((double)timeOut.ToSqlDouble());
                resProc = 0;
                int smsID = int.Parse(resSend[1]);

                // Получаем статус отправленного SMS
                while (resProc == 0 && dtStop > DateTime.Now)
                {
                    string[] resStatus = srv.getStatus(smsID);

                    resProc = int.Parse(resStatus[0]);
                    statusMsg = resStatus[1];

                    if(resProc != 1)
                        Thread.Sleep(2000);
                }

                switch(resProc)
                {
                    case 0:
                        statusMsg = "TimeOut. " + statusMsg;
                        resProc = 5;
                        break;
                    case 1:
                        statusMsg = "Сообщение доставлено. " + statusMsg;
                        break;
                    case 2:
                        statusMsg = "Ошибка отправки. " + statusMsg;
                        break;
                    case 3:
                        statusMsg = "Ошибка доставки. " + statusMsg;
                        break;
                    case 4:
                        statusMsg = "Неизвестная ошибка. " + statusMsg;
                        break;
                    default:
                        break;
                }
            }


            return resProc;
        }


        [SqlProcedure(Name = "sms_send_async")]
        public static SqlInt32 SmsSendAsync(SqlString phone, SqlString text, SqlString title, ref SqlInt32 smsID, ref SqlString statusMsg, SqlString code, SqlInt32 aggregator_id, SqlString url, SqlString userName, SqlString password)
        {
            int resProc = 0;

            WebClient srv = new WebClient(url.Value, userName.Value, password.Value);

            // Посылаем SMS
            string[] resSend = srv.sendSms(phone.Value, text.Value, title.Value, code.Value, aggregator_id.Value);

            // Результат
            resProc = int.Parse(resSend[0]);
            if (resProc == 1)
            {
                smsID = int.Parse(resSend[1]);
                statusMsg = "Сообщение отправлено";
            }
            else
            {
                smsID = 0;
                statusMsg = resSend[1];
            }

            return resProc;
        }

        [SqlProcedure(Name = "sms_send_async_realy")]
        public static void SmsSendAsyncRealy(SqlString phone, SqlString text, SqlString title, SqlString code, SqlInt32 aggregator_id, SqlString url, SqlString userName, SqlString password)
        {
            WebClient srv = new WebClient(url.Value, userName.Value, password.Value);

            //Асинхронно посылаем SMS
            srv.sendSmsAsync(phone.Value, text.Value, title.Value, code.Value, aggregator_id.Value);
        }

        [SqlProcedure(Name = "sms_get_status")]
        public static SqlInt32 SmsGetStatus(SqlInt32 smsID, ref SqlString statusMsg, SqlString url, SqlString userName, SqlString password)
        {
            int resProc = 0;

            WebClient srv = new WebClient(url.Value, userName.Value, password.Value);

            // Получаем статус SMS
            string[] resStatus = srv.getStatus(smsID.Value);

            resProc = int.Parse(resStatus[0]);
            statusMsg = resStatus[1];

            return resProc;
        }
    }
}
