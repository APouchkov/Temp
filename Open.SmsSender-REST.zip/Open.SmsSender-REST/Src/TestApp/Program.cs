using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows.Forms;
using System.Data.SqlTypes;
using System.Threading;

namespace TestApp
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            SqlString statusMsg = "";
            Int32 res = (Int32)Open.SmsSender.Manager.SmsSend("+79168387167", "test", "Open-Broker", ref statusMsg, 10, "https://webservices.open.ru/smswebsrv/index/ws/1", "webservice", "0s8L5S", 1, "7070");
            //Int32 res = (Int32)Open.SmsSender.Manager.SmsSend("+79168387167", "test", "Open-Broker", ref statusMsg, 10, "https://10.48.36.60/smswebsrv/index/ws/1", "webservice", "0s8L5S", 1, "7070");
        }
    }
}