﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Open.SmsSenderRestTest
{
    class SMSSend
    {
        public string phone { get; set; } // - номер телефона, в формате +79201112233
        public string text { get; set; } // - текст сообщения
        public string title { get; set; } // - заголовок
        public string client_code { get; set; } // - код клиента
        public int aggregator_id { get; set; } // - id агрегатора, в настоящий момент используются значения 1 и 3
        public string key { get; set; } // - ключ доступа, предполагается что по нему будет осуществляться идентификация отправителя, для теста можно указать asdf
    }

    class SMSResult
    {
        public class Errors
        {
            public string[] phone { get; set; }
            public string[] key { get; set; }
            public string[] title { get; set; }
            public string[] client_code { get; set; }
            public string[] aggregator_id { get; set; }
        }

        public Errors errors { get; set; }
        public string status { get; set; }
        public string id { get; set; }
        public string errorText { get; set; }

    }



    //{
    //    "errors": {
    //        "phone": [
    //            "Необходимо заполнить поле Phone."
    //        ]
    //}
    //}

    //или
    //{
    //    "errors": {
    //        "key": "Не верно указан код авторизации"
    //    }
    //}
}
