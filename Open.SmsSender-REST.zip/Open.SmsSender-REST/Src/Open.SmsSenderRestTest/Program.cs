﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using System.Net.Http.Headers;

namespace Open.SmsSenderRestTest
{
  class Program
  {
    static void Main(string[] args)
    {
      RunAsync().Wait();
    }

    static async Task RunAsync()
    {
      using (var client = new HttpClient())
      {


        {
          var pairs = new List<KeyValuePair<string, string>>
                    {
                        //phone = "+79168387167", text = "test", title = "Open-Broker", client_code = "7070", aggregator_id = 1, key = "asdf"
                        new KeyValuePair<string, string>("phone", "+79031607325"),
                        new KeyValuePair<string, string>("text", "Тестовый вызов"),
                        new KeyValuePair<string, string>("title", "Open-Broker"),
                        new KeyValuePair<string, string>("client_code", "7070"),
                        new KeyValuePair<string, string>("aggregator_id", "1"),
                        new KeyValuePair<string, string>("key", "asdf"),
                    };

          var content = new FormUrlEncodedContent(pairs);
          System.Net.ServicePointManager.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

          var response = client.PostAsync("https://services_test.clients.open.ru/sms/send", content).Result;

          if (response.IsSuccessStatusCode)
          {
            SMSResult smsResult = response.Content.ReadAsAsync<SMSResult>().Result;

          }
        }

        return;
      }
    }
  }
}
