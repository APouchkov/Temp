﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.SqlServer.Server;
using System.Data.SqlTypes;
using System.Net.Http;

namespace Open.SmsSenderRest
{
    public static class Manager
    {
        /// <summary>
        /// Возвращаемый результат:
        /// 0 - не доставлено
        /// 1 - отправлено
        /// 2 - ошибка отправки (например, ошибка биллинга)
        /// 3 - ошибка доставки (например, истек срок доставки или номер более не обслуживается)
        /// 4 - неизвестная ошибка
        /// 5 - time out
        /// 
        /// см. http://jira.open.ru/browse/PR-859
        /// </summary>
        [SqlProcedure(Name = "sms_send")]
        public static SqlInt32 SmsSend(
            SqlString phone, 
            SqlString text, 
            SqlString title, 
            ref SqlString statusMsg, 
            SqlInt32 timeOut, 
            SqlString url, 
            SqlString userName, // используется как key
            SqlString password, // не используется
            SqlInt32 aggregator_id, 
            SqlString clientCode)
        {
            if (timeOut <= 0)
                throw new Exception("Параметр timeOut должен быть больше 0.");


            int resProc = 0;



            return resProc;
        }

        private static SendResult SmsSendInternal(
            string phone,
            string text,
            string title,
            int timeOut,
            string url,
            string key, // используется как key
            int aggregator_id,
            string clientCode)
        {
            try
            {
                using (var client = new HttpClient())
                {
                    var content = UrlFromParams(phone, text, title, clientCode, aggregator_id, key);

                    // force ignore errors of self-signed cert
                    System.Net.ServicePointManager.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

                    var response = client.PostAsync("https://services_test.clients.open.ru/sms/send", content).Result;
                    if (response.IsSuccessStatusCode)
                    {
                        //SMSResult smsResult = response.Content.
                        SMSResult smsResult = response.Content.ReadAsAsync<SMSResult>().Result;
                        return new SendResult(smsResult);
                    }

                    return new SendResult(5, "");

                }
            }
            catch (Exception ex)
            {
                Exception tempEx = ex;
                StringBuilder statusMsg = new StringBuilder();
                while (tempEx != null)
                {
                    statusMsg.AppendLine(tempEx.Message);
                    tempEx = tempEx.InnerException;
                }
                return new SendResult(5, statusMsg.ToString());
            }
            


        }

        private static FormUrlEncodedContent UrlFromParams(
            string phone,
            string text,
            string title,
            string clientCode,
            int aggregator_id,
            string key
            )
        {
            
            var pairs = new List<KeyValuePair<string, string>>
            {
                //phone = "+79168387167", text = "test", title = "Open-Broker", client_code = "7070", aggregator_id = 1, key = "asdf"
                new KeyValuePair<string, string>("phone", phone),
                new KeyValuePair<string, string>("text", text),
                new KeyValuePair<string, string>("title", title),
                new KeyValuePair<string, string>("client_code", clientCode),
                new KeyValuePair<string, string>("aggregator_id", aggregator_id.ToString()),
                new KeyValuePair<string, string>("key", key)
            };

            return new FormUrlEncodedContent(pairs);
        }

        private class SendResult
        {
            public int status { get; set; }
            public string errorText { get; set; }
            public SendResult(SMSResult smsResult)
            {
                StringBuilder statusMsg = new StringBuilder();
                int restatus;
                statusMsg.AppendLine(smsResult.errorText);
                if (Int32.TryParse(smsResult.status, out restatus))
                {
                    switch (restatus)
                    {
                        case 0:
                            statusMsg.AppendLine("TimeOut.");
                            restatus = 5;
                            break;
                        case 1:
                            statusMsg.AppendLine("Сообщение доставлено.");
                            break;
                        case 2:
                            statusMsg.AppendLine("Ошибка отправки.");
                            break;
                        case 3:
                            statusMsg.AppendLine("Ошибка доставки.");
                            break;
                        case 4:
                            statusMsg.AppendLine("Неизвестная ошибка.");
                            break;
                        default:
                            break;
                    }
                }
                else
                {
                    restatus = 5;
                    statusMsg.AppendLine("Неизвестная ошибка. ");
                }
                status = restatus;
                errorText = statusMsg.ToString();
            }
            public SendResult(int restatus, string statusMsg)
            {
                status = restatus;
                errorText = statusMsg.ToString();
            }
        }

        /// <summary>
        /// Формат того JSON, который приходит от сервиса
        /// </summary>
        private class SMSResult
        {
            public class Errors
            {
                public string[] phone { get; set; }
                public string[] key { get; set; }
                public string[] title { get; set; }
                public string[] client_code { get; set; }
                public string[] aggregator_id { get; set; }
            }

            public Errors errors { get; set; }
            public string status { get; set; }
            public string id { get; set; }
            public string errorText { get; set; }

        }

    }
}
